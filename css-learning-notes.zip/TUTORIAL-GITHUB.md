# 📚 TUTORIAL GITHUB - Passo a Passo Simples

## 🎯 MÉTODO MAIS FÁCIL (Arrastar e Soltar)

### Passo 1: Criar conta no GitHub
1. Entre em **https://github.com**
2. Clique em **"Sign up"** (Criar conta)
3. Preencha com seu email, senha e nome de usuário
4. Confirme o email que eles mandarem

### Passo 2: Criar um novo repositório
1. Depois de logar, clique no **"+"** no canto superior direito
2. Clique em **"New repository"**
3. Dê um nome, por exemplo: `trabalho-basquete`
4. Deixe como **Public** (público)
5. **NÃO marque** nenhuma caixinha (deixe tudo desmarcado)
6. Clique em **"Create repository"**

### Passo 3: Fazer upload dos arquivos
1. Na página que abrir, clique em **"uploading an existing file"**
2. **Arraste TODOS os arquivos e pastas** para a área indicada:
   - index.html
   - historia.html
   - regras.html
   - contato.html
   - README.md
   - TUTORIAL-GITHUB.md
   - Pasta **css** (com o arquivo styles.css dentro)
   - Pasta **images** (com os arquivos dentro)

3. Espere todos os arquivos carregarem (barra verde completa)
4. Lá embaixo, clique em **"Commit changes"** (botão verde)

### Passo 4: Ativar o GitHub Pages (site online)
1. No seu repositório, clique em **"Settings"** (Configurações)
2. No menu lateral esquerdo, clique em **"Pages"**
3. Em **"Source"**, selecione **"main"** (ou "master")
4. Clique em **"Save"**
5. Aguarde uns 2 minutos

### Passo 5: Pegar o link do site
1. Volte em **"Settings"** → **"Pages"**
2. Vai aparecer um link assim: `https://seu-usuario.github.io/trabalho-basquete/`
3. **COPIE ESSE LINK** - é ele que você vai entregar pro professor! ✅

---

## 📝 Checklist antes de entregar

- [ ] Todas as 4 páginas HTML estão no repositório?
- [ ] A pasta `css` com o arquivo `styles.css` está lá?
- [ ] A pasta `images` com as imagens está lá?
- [ ] O site está funcionando quando você abre o link?
- [ ] Você consegue navegar entre as páginas?

---

## 🎨 Sobre as Imagens

O logo já está pronto (logo.svg)! Mas você precisa adicionar 3 imagens:

**Opção 1 - Baixar imagens:**
1. Vá no Google Imagens
2. Pesquise: "basketball", "basketball court", "basketball history"
3. Baixe 3 imagens
4. Renomeie para: `basquete.jpg`, `historia.jpg`, `quadra.jpg`
5. No GitHub, vá na pasta `images`
6. Clique em "Add file" → "Upload files"
7. Arraste as 3 imagens
8. Commit changes

**Opção 2 - Usar placeholders (mais fácil!):**
As imagens já estão configuradas. Se você não colocar imagens reais, o navegador vai mostrar um ícone de imagem quebrada, mas o site funciona normal!

---

## ❓ Problemas Comuns

**"Meu site não aparece"**
- Espere 5 minutos depois de ativar o Pages
- Verifique se a configuração do Pages está em "main"
- Tente abrir o link em uma aba anônima

**"As imagens não aparecem"**
- Normal! Você precisa adicionar as imagens na pasta `images`
- Ou deixe assim mesmo, o site funciona

**"Aparece erro 404"**
- Verifique se o nome do arquivo é exatamente `index.html` (minúsculo)
- Espere mais um pouco, às vezes demora

---

## 🚀 Para entregar ao professor

1. **Link do repositório:** `https://github.com/seu-usuario/trabalho-basquete`
2. **Link do site online:** `https://seu-usuario.github.io/trabalho-basquete/`

Pode entregar os dois links! 😊

---

## 💡 Dica Final

Depois que subir tudo, abra o link do site e navegue pelas 4 páginas para ter certeza que está tudo funcionando!

Boa sorte! 🏀
